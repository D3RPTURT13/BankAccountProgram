
import java.util.Scanner;

public class AccountTester{
	
	private double moneySaved;
	private String name;
	private String account;
	double currentSaved = 0.0;
	public static void main(String[] args) {
		System.out.println("Welcome to the Bank of Depression:");
		System.out.println("Name of person: ");
		Scanner scnr = new Scanner(System.in);
		String n1 = scnr.nextLine();
		System.out.println("Welcome Back! " + n1);
		System.out.println("What will you be doing? (Deposit, Check (if you have a savings account), or Withdrawal? capitalize): ");
		String o1 = scnr.nextLine();
		if (o1.equals("Withdrawal")) {
			System.out.println("Account Type (Capitalize first letter): ");
			String m11 = scnr.next();
		if(m11.equals("Savings")) {
			System.out.println("How much will be withdrawed?: ");
			double x1 = scnr.nextDouble();
			System.out.println("You have requested to withdraw $" + x1 + ", is this correct? ");
			String z1 = scnr.nextLine();
			if (z1.equals("yes")) {
				System.out.println("You have withdrawed $" + x1 + ", thank you for having depression" );	
				}else if (z1.equals("no")) {
					System.out.println("No amount has been taken out of your account and you may restart to reconfirm your choice, thank you for having depression!");
		}else if(m11.equals("Checkings")) {
			System.out.println("How much will be withdrawed?: ");
			double q1 = scnr.nextDouble();
			System.out.println("How many times have you withdrawed so far?: ");
			int r1 = scnr.nextInt();
			int checkingAttempts = 3 - r1;
			if (checkingAttempts == 0) {
				checkingAttempts = 0;
			}else if (checkingAttempts > 0) {
				if (checkingAttempts < 3) {
					if(checkingAttempts < 0) {
				checkingAttempts = 3 - r1;
					}
				}
			}
			if (r1 > 0) {
				System.out.println("Along with your withdrawal of " + "$"+ q1 + ", you will be charged an additional $1 in transaction fee, are you ok with this? ");
				String s1 = scnr.next();
				if (s1.equals("yes")) {
				System.out.println("You have withdrawed $" + q1 + " plus and additional fee of $1, thank you for having depression");	
				}else if (s1.equals("no")) {
					System.out.println("No amount has been taken out of your account and you may restart to reconfirm your choice, thank you for having depression!");
				}
			}else if (r1 <= 0) {
				
				System.out.println("You are about to withdraw $" + q1 + ", is this correct? ");
				String s1 = scnr.next();
				if (s1.equals("yes")) {
				System.out.println("You have withdrawed $" + q1 + ", and curently have " + checkingAttempts + " Free withdrawals left, thank you for having depression" );	
				}else if (s1.equals("no")) {
					System.out.println("No amount has been taken out of your account and you may restart by pressing the green button to reconfirm your choice, thank you for having depression!");
				}
			 }
			}
			}
	}
		if(o1.equals("Deposit")) {
			System.out.println("How much would you like to deposit?(enter in 0.00 form without $ sign)");
			double y1 = scnr.nextDouble();
			System.out.println("You want to deposit $" + y1 + ", is this correct?");
			String w1 = scnr.nextLine();
			if (w1.equals("yes")) {
				System.out.println("You have Deposited $" + y1 + " into your account, thank you for having depression!");	
				}else if (w1.equals("no")) {
					System.out.println("No amount has been taken into your account and you may restart by pressing the green button to reconfirm your choice, thank you for having depression!");
				}
		}
		if(o1.equals("Check")) {
			System.out.println("What year did you create your savings account? ");
			int v1 = scnr.nextInt();
			System.out.println("What month did you register?(enter in number form) ");
			int u1 = scnr.nextInt();
			System.out.println("you have entered your date of joining as the " + u1 + "th of " + v1 + ", is this correct?");
			String t1 = scnr.nextLine();
			if (t1.equals("yes")) {
			int yearsMonths = 2017-v1;
			yearsMonths = yearsMonths * 12;
			int Months = yearsMonths - u1;
			int monthlyInterest = Months * 100;
			System.out.println("Your Monthly Interest Rate is currently $ " + monthlyInterest + ", thank you for having depression!" );
			}else if(t1.equals("no")) {
				System.out.println("Please restart by hitting green button and reentering info, thank you for having depression!");
				}
			}
	}
}
