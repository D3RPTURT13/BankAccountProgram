
import java.util.Random;
import java.util.Scanner;

public class AccountTester{
	private double moneySaved;
	private String name;
	private String account;
	double currentSaved = 0.0;
	public static void main(String[] args) {
		NewAccount account1 = new NewAccount(12098743);
		account1.getAccount();
		System.out.println("Welcome to the Bank of Depression:");
		System.out.println("Name of person: ");
		Scanner scnr = new Scanner(System.in);
		String n1 = scnr.nextLine();
		System.out.println("Welcome! " + n1);
		System.out.println("What will you be doing? (Deposit, Check (if you have a savings account), Withdrawal, or would you like to make an account with the bank(Account)? capitalize): ");
		String o1 = scnr.nextLine();
		if (o1.equals("Withdrawal")) {
			System.out.println("Account Type (Capitalize first letter): ");
			String m11 = scnr.next();
		if(m11.equals("Savings")) {
			System.out.println("How much will be withdrawed?: ");
			double x1 = scnr.nextDouble();
			System.out.println("You have requested to withdraw $" + x1 + ", is this correct? ");
			String z1 = scnr.nextLine();
			if (z1.equals("yes")) {
				System.out.println("You have withdrawed $" + x1 + ", thank you for having depression" );	
				}else if (z1.equals("no")) {
					System.out.println("No amount has been taken out of your account and you may restart to reconfirm your choice, thank you for having depression!");
		}else if(m11.equals("Checkings")) {
			System.out.println("How much will be withdrawed?: ");
			double q1 = scnr.nextDouble();
			System.out.println("How many times have you withdrawed so far?: ");
			int r1 = scnr.nextInt();
			int checkingAttempts = 3 - r1;
			if (checkingAttempts == 0) {
				checkingAttempts = 0;
			}else if (checkingAttempts > 0) {
				if (checkingAttempts < 3) {
					if(checkingAttempts < 0) {
				checkingAttempts = 3 - r1;
					}
				}
			}
			if (r1 > 0) {
				System.out.println("You have withdrawed $" + q1 + " plus and additional fee of $1, thank you for having depression");	
			}else if (r1 <= 0) {
				System.out.println("You have withdrawed $" + q1 + ", and curently have " + checkingAttempts + " Free withdrawals left, thank you for having depression" );	
			 }
			}
			}
	}
		if(o1.equals("Deposit")) {
			System.out.println("How much would you like to deposit?(enter in 0.00 form without $ sign)");
			double y1 = scnr.nextDouble();
				System.out.println("You have Deposited $" + y1 + " into your account, thank you for having depression!");	
		}
		if(o1.equals("Check")) {
			System.out.println("What year did you create your savings account? ");
			int v1 = scnr.nextInt();
			System.out.println("What month did you register?(enter in number form) ");
			int u1 = scnr.nextInt();
			int yearsMonths = 2017-v1;
			yearsMonths = yearsMonths * 12;
			int Months = yearsMonths - u1;
			int monthlyInterest = Months * 100;
			System.out.println("Your Monthly Interest Rate is currently $ " + monthlyInterest + ", thank you for having depression!" );
						}
		if(o1.equals("Account")) {
			System.out.println("what is you name? ");
			String A1 = scnr.nextLine();
			System.out.println("Your Name is " + A1 + "and your account number for the bank is " + account1 + ", be sure to remember it, and  thank you for getting depression!");

		} else {
			System.out.println("Please enter a correct value, restart by pressing green button and try again");
		}
	}
}

