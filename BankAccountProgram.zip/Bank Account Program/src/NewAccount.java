
public class NewAccount {
	private int accountNumber;
	public NewAccount(int accountnumber) {
		this.accountNumber = accountnumber;
	}
	    public int getAccount() {
			return accountNumber;
		}
		
		public void setAccount(int accountNumber) {
			this.accountNumber = accountNumber;
		}
}

